package model;

public class Cart {
	
	private int cartID;
	private int numItems;
	
	
	public Cart(int cartID, int numItems) {
		this.cartID = cartID;
		this.numItems = numItems;
	}
	
	public Cart() {
		
	}

	public int getCartID() {
		return cartID;
	}

	public void setCartID(int cartID) {
		this.cartID = cartID;
	}

	public int getNumItems() {
		return numItems;
	}

	public void setNumItems(int numItems) {
		this.numItems = numItems;
	}
	
	
	

}
